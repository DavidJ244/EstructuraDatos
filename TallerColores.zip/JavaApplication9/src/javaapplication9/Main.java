/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication9;

/**
 *
 * @author l52
 */
public class Main {
    public static void main(String[] args) {
        EscudoBarcelona escudoBarcelona = new EscudoBarcelona("FC Barcelona", "Marrón", "Morado", "Azul");

        System.out.println("Nombre del equipo: " + escudoBarcelona.getNombre());
    }
}
