/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication9;

public class EscudoBarcelona {
    // Atributos
    private String nombre;
    private String colorPrincipal;
    private String colorSecundario;
    private String colorTerciario;

    // Constructor
    public EscudoBarcelona(String nombre, String colorPrincipal, String colorSecundario, String colorTerciario) {
        this.nombre = nombre;
        this.colorPrincipal = colorPrincipal;
        this.colorSecundario = colorSecundario;
        this.colorTerciario = colorTerciario;
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColorPrincipal() {
        return colorPrincipal;
    }

    public void setColorPrincipal(String colorPrincipal) {
        this.colorPrincipal = colorPrincipal;
    }

    public String getColorSecundario() {
        return colorSecundario;
    }

    public void setColorSecundario(String colorSecundario) {
        this.colorSecundario = colorSecundario;
    }

    public String getColorTerciario() {
        return colorTerciario;
    }

    public void setColorTerciario(String colorTerciario) {
        this.colorTerciario = colorTerciario;
    }

    // Métodos adicionales
    public void mostrarColores() {
        System.out.println("Colores del escudo: " + colorPrincipal + ", " + colorSecundario + " y " + colorTerciario);
    }

    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
    }

    public void cambiarNombre(String nuevoNombre) {
        this.nombre = nuevoNombre;
    }
}

// Crear un objeto de la clase EscudoBarcelona e imprimir un atributo
public class Main {
    public static void main(String[] args) {
        EscudoBarcelona escudoBarcelona = new EscudoBarcelona("FC Barcelona", "Marrón", "Morado", "Azul");

        System.out.println("Nombre del equipo: " + escudoBarcelona.getNombre());
    }
}
